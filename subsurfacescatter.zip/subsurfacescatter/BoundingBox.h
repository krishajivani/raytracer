#pragma once

#include "Plane.h"
#include "Ray.h"
#include <Eigen/Core>
#include <limits>

using namespace Eigen;

/**
 * Box which contains a mesh, used to optmise rendering.
 **/
class BoundingBox
{
public:
    Vector3f min;
    Vector3f max;

    BoundingBox() {}

    bool intersects(Ray ray);
    float getIntersectT(Ray ray);
    void setValues(Vector3f min, Vector3f max);
    void expand(BoundingBox other);
    int longestAxis();
};