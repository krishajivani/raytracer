#include <Eigen/Dense>

using namespace Eigen;

/**
 * The view of the image, defined by directional vectors and position.
 **/
class Camera
{
    /** Parameters:
          eye : (3,) -- the camera's location, aka viewpoint (a 3D point)
          target : (3,) -- where the camera is looking: a 3D point that appears centered in the view
          up : (3,) -- the camera's orientation: a 3D vector that appears straight up in the view
          vfov : float -- the full vertical field of view in degrees
          aspect : float -- the aspect ratio of the camera's view (ratio of width to height)
    **/

public:
    Vector3f eye;
    Vector3f target;
    Vector3f up;
    float vfov;
    float aspect;
};